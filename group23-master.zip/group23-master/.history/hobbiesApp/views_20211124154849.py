import os
from django.shortcuts import render, redirect
from django.http import HttpResponse
from . import database
from .models import *
from django.contrib.auth import get_user_model
from .forms import CustomUserCreationForm, addHobbiesForm, viewHobbiesForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
import datetime

# Create your views here.


def registerPage(request):

    form = CustomUserCreationForm()

    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'User created for' + user)
            return redirect('login')

    context = {'form': form}
    return render(request, 'hobbiesApp/register.html', context)


def loginPage(request):

    if request.method == 'POST':
        # here we are fetching the fieldnames from login form on login.html
        username = request.POST.get('username')
        password = request.POST.get('password')

        # this is djangos method to automatically verify(authenticate) the user
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('profilePage')

    context = {}
    return render(request, 'hobbiesApp/login.html')


def health(request):
    """Takes an request as a parameter and gives the count of pageview objects as reponse"""
    return HttpResponse(PageView.objects.count())


def test(request):

    return render(request, 'hobbiesApp/testPage.html')


def profile(request):
    user = MyUser.objects.get(username=request.user)
    image = user.image

    email = user.email
    city = user.city
    dob = user.dob

    #age = datetime.date.today() - dob

    today = datetime.date.today()
    age = today.year - dob.year - \
        ((today.month, today.day) < (dob.month, dob.day))

    context = {'user': user, 'image': image, 'email': email,
               'city': city, 'dob': dob, 'age': age, }

    return render(request, 'hobbiesApp/profile.html', context)


def hobbies(request):

    hobby = Hobby.objects.all()
    user = MyUser.objects.get(username=request.user)
    user.save()
    form = addHobbiesForm()
    form2 = viewHobbiesForm()

    if request.method == 'POST' and 'addHobby' in request.POST:
        form = addHobbiesForm(request.POST)
        if form.is_valid():

            # we need the ID to add it onto the users hobby fields
            hobbyID = form.save()

            user.hobbies.add(hobbyID.id)
            form.save()
            return redirect('/hobbies/')

    if request.method == 'POST' and 'addHobbyToUser' in request.POST:
        hobby_selected = request.POST.get('selectedHobbies')
        user.hobbies.add(hobby_selected)
        return redirect('/hobbies/')

    context = {'form': form, 'form2': form, 'hobby': hobby}

    return render(request, 'hobbiesApp/hobbies.html', context)

####
