## Group Members:

1. Cristian-Daniel Mina - 180374939 - ec18403
Contributions:
- Profile Page and Similar Hobbies Page (Frontend + Backend)
2. Muhammad Azaan Zafar - 180311945 - ec19042
Contributions:
- Login & Register (Backend), Profile Page (Frotnend + Backend), Add Hobbies (Frontend + Backend)
3. Saeed Kaddoura - 180413135 - bt18673
Contributions:
- Similar Hobbies (Backend) and Unit Tests

## OpenShift URL:



## Username/Password Admin:
User: admin
Pass: admin

## Username/Password Users:

User: azaan
Pass: user1234
User: cristian
Pass: user1234
User: saeed
Pass: user1234
User: paulo
Pass: user1234
User: soren
Pass: user1234
User: joseph
Pass: user1234
User: arthur
Pass: user1234


